
from setuptools import setup

setup(
    name="newtonpackage",
    version="1.0",
    requirements=["requests<=2.21.0"],
    description="realisation of the Newton's method",
    packages=["newtonpackage"]
)
